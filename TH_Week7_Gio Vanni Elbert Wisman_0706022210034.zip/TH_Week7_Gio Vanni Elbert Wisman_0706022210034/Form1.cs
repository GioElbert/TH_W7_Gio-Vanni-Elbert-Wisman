﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.ApplicationServices;
using Microsoft.VisualBasic.Devices;
using static System.Net.Mime.MediaTypeNames;

namespace TakeHome_7
{
    public partial class Form1 : Form
    {
        private static List<ClassMovie> daftarMovies = new List<ClassMovie>();
        public bool[,] RandomKursi()
        {
            Random random = new Random();
            int kursiKosong = random.Next(30, 80);
            bool[,] myArray = new bool[10, 10];

            while (kursiKosong != 0)
            {
                int b = random.Next(0, 10);
                int k = random.Next(0, 10);
                if (myArray[b,k] == false)
                {
                    myArray[b,k] = true;
                    kursiKosong--;
                }
            }
            return myArray;
        }
        public Form1()
        {
            InitializeComponent();
             //Input Data Movie

            List<playingTime> daftarPlayTime1 = new List<playingTime>();

            playingTime playTime1 = new playingTime("12:30",RandomKursi());
            daftarPlayTime1.Add(playTime1);
            playingTime playTime2 = new playingTime("14:05", RandomKursi());
            daftarPlayTime1.Add(playTime2);
            playingTime playTime3 = new playingTime("20:30", RandomKursi());
            daftarPlayTime1.Add(playTime3);

            ClassMovie movie1 = new ClassMovie("The Popes Excorcist", "Image0", "Film Horor", daftarPlayTime1);
            daftarMovies.Add(movie1);


            List<playingTime> daftarPlayTime2 = new List<playingTime>();

            playingTime playTime21 = new playingTime("12:00", RandomKursi());
            daftarPlayTime2.Add(playTime21);
            playingTime playTime22 = new playingTime("15:05", RandomKursi());
            daftarPlayTime2.Add(playTime22);
            playingTime playTime23 = new playingTime("19:30", RandomKursi());
            daftarPlayTime2.Add(playTime23);

            ClassMovie movie2 = new ClassMovie("Ride On ", "Image1", "Film Komedi", daftarPlayTime2);
            daftarMovies.Add(movie2);



            List<playingTime> daftarPlayTime3 = new List<playingTime>();

            playingTime playTime31 = new playingTime("11:00", RandomKursi());
            daftarPlayTime3.Add(playTime31);
            playingTime playTime32 = new playingTime("13:05", RandomKursi());
            daftarPlayTime3.Add(playTime32);
            playingTime playTime33 = new playingTime("21:00", RandomKursi());
            daftarPlayTime3.Add(playTime33);

            ClassMovie movie3 = new ClassMovie("Super Mario Bros", "Image2", "Film Petualangan", daftarPlayTime3);
            daftarMovies.Add(movie3);

            List<playingTime> daftarPlayTime4 = new List<playingTime>();

            playingTime playTime41 = new playingTime("10:00", RandomKursi());
            daftarPlayTime4.Add(playTime41);
            playingTime playTime42 = new playingTime("11:30", RandomKursi());
            daftarPlayTime4.Add(playTime42);
            playingTime playTime43 = new playingTime("14:00", RandomKursi());
            daftarPlayTime4.Add(playTime43);

            ClassMovie movie4 = new ClassMovie("A Quit Place", "Image3", "Film Action", daftarPlayTime4);
            daftarMovies.Add(movie4);


            List<playingTime> daftarPlayTime5 = new List<playingTime>();

            playingTime playTime51 = new playingTime("09:00", RandomKursi());
            daftarPlayTime5.Add(playTime51);
            playingTime playTime52 = new playingTime("11:45", RandomKursi());
            daftarPlayTime5.Add(playTime52);
            playingTime playTime53 = new playingTime("16:00", RandomKursi());
            daftarPlayTime5.Add(playTime53);

            ClassMovie movie5 = new ClassMovie("Buya Hamka", "Image4", "Film Drama Biopik", daftarPlayTime5);
            daftarMovies.Add(movie5);

            List<playingTime> daftarPlayTime6 = new List<playingTime>();

            playingTime playTime61 = new playingTime("08:00", RandomKursi());
            daftarPlayTime6.Add(playTime61);
            playingTime playTime62 = new playingTime("12:45", RandomKursi());
            daftarPlayTime6.Add(playTime62);
            playingTime playTime63 = new playingTime("14:00", RandomKursi());
            daftarPlayTime6.Add(playTime63);

            ClassMovie movie6 = new ClassMovie("Jin dan Jun", "Image5", "Film Horor", daftarPlayTime6);
            daftarMovies.Add(movie6);


            List<playingTime> daftarPlayTime7 = new List<playingTime>();

            playingTime playTime71 = new playingTime("07:40", RandomKursi());
            daftarPlayTime7.Add(playTime71);
            playingTime playTime72 = new playingTime("13:45", RandomKursi());
            daftarPlayTime7.Add(playTime72);
            playingTime playTime73 = new playingTime("17:00", RandomKursi());
            daftarPlayTime7.Add(playTime73);

            ClassMovie movie7 = new ClassMovie("Sewu Dino", "Image6", "Film Horor", daftarPlayTime7);
            daftarMovies.Add(movie7);

            List<playingTime> daftarPlayTime8 = new List<playingTime>();

            playingTime playTime81 = new playingTime("10:00", RandomKursi());
            daftarPlayTime8.Add(playTime81);
            playingTime playTime82 = new playingTime("15:45", RandomKursi());
            daftarPlayTime8.Add(playTime82);
            playingTime playTime83 = new playingTime("18:30", RandomKursi());
            daftarPlayTime8.Add(playTime83);

            ClassMovie movie8 = new ClassMovie("John Wick", "Image7", "Film Action", daftarPlayTime8);
            daftarMovies.Add(movie8);




            //Tampilkan Movie


            for (int b = 0; b < daftarMovies.Count; b++)
            {
                // Create a new Image control
                PictureBox picture = new PictureBox();

                // Set the properties of the textbox
                picture.Name = "img" + b.ToString();

                string imgPath = "C:\\Users\\GEOVANI\\Downloads\\Image" + b.ToString() + ".jpg";
                picture.ImageLocation = imgPath;
                picture.SizeMode = PictureBoxSizeMode.StretchImage;
                picture.Size = new Size(150, 200);
                picture.Location = new Point(50, (100 + b * 250));
                // Add the Label Judul to the form
                this.panel1.Controls.Add(picture);


                ////////////////////////###########################////////////////////////////
                // Create a new Label control
                Label label = new Label();

                // Set the properties of the textbox
                label.Name = "lbljdl" + b.ToString();
                label.Text = daftarMovies[b].getJudulMovie();
                label.Size = new Size(100, 30);
                label.Font = new Font(label.Font, FontStyle.Bold);
                label.Location = new Point(200, (100 + b * 250));
                // Add the textbox to the form
                this.panel1.Controls.Add(label);

                ////////////////////////###########################////////////////////////////


                // Create a new Label Desc control
                Label labeldesc = new Label();

                // Set the properties of the textbox
                labeldesc.Name = "lbldesc" + b.ToString();
                labeldesc.Text = daftarMovies[b].getDescMovie();
                labeldesc.Size = new Size(100, 30);

                labeldesc.Location = new Point(200, (150 + b * 250));

                // Add the textbox to the form
                this.panel1.Controls.Add(labeldesc);


                //create a button play time control
                for (int i = 0; i < daftarMovies[b].getPlayingTime().Count; i++)
                {
                    Button btnplay = new Button();
                    btnplay.Name = "btnplayTime" + b.ToString() + i.ToString();
                    btnplay.Text = daftarMovies[b].getPlayingTime()[i].getTime();
                    btnplay.Size = new Size(70, 30);

                    btnplay.Location = new Point((50 + (i * 75)), (300 + b * 250));
                    btnplay.Click += new EventHandler(btnPlay_Click);
                    this.panel1.Controls.Add(btnplay);
                }
            }


        }

        private void btnPlay_Click(object sender, EventArgs e)
        {
            Button clickedButton = (Button)sender;
           
            // Display a message box with an input field and OK/Cancel buttons
            DialogResult dialogResult = MessageBox.Show("Enter Number of Ticket!", "Input Dialog", MessageBoxButtons.OKCancel);

            // If the user clicks the OK button, get the input value and display it
            if (dialogResult == DialogResult.OK)
            {
                string inputTiket = Interaction.InputBox("Please enter the number of ticket you want", "Input Dialog", "");

                string filterNoMovie = new string(clickedButton.Name.Where(c => Char.IsDigit(c)).ToArray());

                int noMovie = int.Parse(filterNoMovie);
                string playTimeNow = clickedButton.Text;

                foreach (playingTime playingtime in daftarMovies[noMovie / 10].getPlayingTime())
                {
                    if (playTimeNow == playingtime.getTime())
                    {
                        Form2 form2 = new Form2 (inputTiket, playTimeNow, playingtime.getArrayKursi());
                        form2.Show();
                    }

                }

            }


        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
            

        }


    }
}
