﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TakeHome_7
{
    class playingTime
    {
        private string time;
        private bool[,] myArray = new bool[10, 10];
        public playingTime(string time, bool[,] myArray) 
        {
            this.time = time;
            this.myArray = myArray;
        }
        public void setTime(string time)
        {
            this.time = time;

        }
        public string getTime()
        {
            return this.time;
        }
        public bool[,] getArrayKursi() 
        { 
            return this.myArray;
        }

        public void setArrayKursi(bool[,] array) 
        { 
            this.myArray = array; 
        }
    }
    internal class ClassMovie
    {
       private string JudulMovie;
       private string ImageMovie;
       private  string DescMovie;
       
       private List <playingTime> PlayingTime = new List <playingTime> ();


        public ClassMovie (string judulMovie , string imageMovie, string descMovie , List <playingTime> playingTime )
        {
            this.JudulMovie = judulMovie;
            this.ImageMovie = imageMovie;
            this.DescMovie = descMovie;
            this.PlayingTime = playingTime;
        }
        public void setJudulMovie(string judul)
        {
            this.JudulMovie = judul;
        }
        public string getJudulMovie()
        {
            return this.JudulMovie;
        }

        public void setImageMovie(string url)
        {
            this.ImageMovie = url;
        }
        public string getImageMovie()
        {
            return this.ImageMovie;
        }

        public void setDescMovie(string desc)
        {
            this.DescMovie = desc;
        }
        public string getDescMovie()
        {
            return this.DescMovie;
        }

        public void setPlayingTime(playingTime playTime)
        {
            this.PlayingTime.Add(playTime);
        }
        public string getdescMovie(int index)
        {
            return this.DescMovie;
        }

        public List <playingTime> getPlayingTime()
        {
            return this.PlayingTime;
        }

    }


}
