﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TakeHome_7
{
    public partial class Form2 : Form
    {
        public int jmlTiket = 0;
        public bool[,] simpanMyArray;
        public Form2(string tiket ,string playTime, bool[,] myArray)
        {
            InitializeComponent();
            simpanMyArray = myArray;

            jmlTiket = int.Parse(tiket);
            lblTiket.Text = "jumlah Tiket: " + tiket.ToString();

            //ketersedia kursi
           


            for (int b = 0; b < 10; b++)
            {
                for (int k = 0; k < 10; k++)
                {
                    Button btnKursi = new Button();
                    btnKursi.Name = "btn" + b.ToString() + k.ToString();
                    btnKursi.Text = "";
                    btnKursi.Size = new Size(30, 30);
                    if (k > 4)
                    {
                        btnKursi.Location = new Point((250 + (k * 40)), (60 + b * 40));

                    }
                    else
                    {
                        btnKursi.Location = new Point((150 + (k * 40)), (60 + b * 40));
                    }
                    btnKursi.Enabled = myArray[b,k];
                    if (myArray[b,k])
                    {
                        btnKursi.BackColor = Color.Green;
                    }
                    else
                    {
                        btnKursi.BackColor= Color.Orange;
                    }

                    btnKursi.Click += new EventHandler(btnKursi_Click);
                    this.Controls.Add(btnKursi);
                }
            }

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            MessageBox.Show("Terima Kasih");

        }

        private void btnKursi_Click (object sender, EventArgs e)
        {
            Button clickedButton = (Button)sender;

            if (clickedButton.BackColor == Color.Red)
            {
                jmlTiket++;
                clickedButton.BackColor = Color.Green;
                lblTiket.Text = "Jumlah tiket: " + jmlTiket.ToString();
            }
            else
            {



                if (jmlTiket > 0)
                {


                    clickedButton.BackColor = Color.Red;
                    jmlTiket--;
                    lblTiket.Text = "Jumlah tiket: " + jmlTiket.ToString();
                }
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
